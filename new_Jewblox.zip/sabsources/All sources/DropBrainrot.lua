repeat task.wait() until game:IsLoaded()

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local CoreGui = game:GetService("CoreGui")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local character
local hrp

local function setupCharacter(char)
    character = char
    hrp = character:WaitForChild("HumanoidRootPart")
end

if player.Character then setupCharacter(player.Character) end
player.CharacterAdded:Connect(setupCharacter)

-- ═══════════════════════════════════════════════════════
-- DROP BRAINROT SYSTEM (EXACT FROM KAWATAN HUB)
-- ═══════════════════════════════════════════════════════

local dropBusy = false
local FLOAT_DROP_HEIGHT = 20
local floatConn = nil

local function doDrop()
    if dropBusy or not hrp then return end
    dropBusy = true
    
    if floatConn then floatConn:Disconnect() floatConn = nil end
    
    local origY = hrp.Position.Y
    local targetY = origY + FLOAT_DROP_HEIGHT
    
    floatConn = RunService.Heartbeat:Connect(function()
        if not hrp then return end
        
        local diff = targetY - hrp.Position.Y
        
        hrp.AssemblyLinearVelocity = Vector3.new(
            hrp.AssemblyLinearVelocity.X,
            math.clamp(diff * 25, -300, 300),
            hrp.AssemblyLinearVelocity.Z
        )
        
        if hrp.Position.Y >= targetY - 1 then
            hrp.AssemblyLinearVelocity = Vector3.new(
                hrp.AssemblyLinearVelocity.X,
                0,
                hrp.AssemblyLinearVelocity.Z
            )
            floatConn:Disconnect()
            floatConn = nil
            dropBusy = false

            -- Watch for landing then fully heal
            local landConn
            landConn = RunService.Heartbeat:Connect(function()
                if not hrp then landConn:Disconnect() return end
                if math.abs(hrp.AssemblyLinearVelocity.Y) < 2 then
                    local humanoid = character and character:FindFirstChildOfClass("Humanoid")
                    if humanoid then
                        humanoid.Health = humanoid.MaxHealth
                    end
                    landConn:Disconnect()
                end
            end)
        end
    end)
end

-- ═══════════════════════════════════════════════════════
-- DROP BRAINROT TOGGLE SYSTEM
-- ═══════════════════════════════════════════════════════

local DropBrainrotEnabled = false
local dropBrainrotLoop = nil

local function startDropBrainrot()
    if dropBrainrotLoop then return end
    
    dropBrainrotLoop = task.spawn(function()
        while DropBrainrotEnabled do
            if not dropBusy and hrp then
                doDrop()
            end
            task.wait(5)
        end
    end)
end

local function stopDropBrainrot()
    if dropBrainrotLoop then
        task.cancel(dropBrainrotLoop)
        dropBrainrotLoop = nil
    end
    if floatConn then
        floatConn:Disconnect()
        floatConn = nil
    end
    if hrp then
        hrp.AssemblyLinearVelocity = Vector3.new(
            hrp.AssemblyLinearVelocity.X,
            0,
            hrp.AssemblyLinearVelocity.Z
        )
    end
    dropBusy = false
end

-- ═══════════════════════════════════════════════════════
-- SMALL GUI
-- ═══════════════════════════════════════════════════════

local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "DropBrainrotGUI"
ScreenGui.ResetOnSpawn = false
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ScreenGui.Parent = CoreGui

local SmallDropGUI = Instance.new("Frame")
SmallDropGUI.Name = "SmallDropBrainrotGUI"
SmallDropGUI.Size = UDim2.new(0, 160, 0, 40)
SmallDropGUI.Position = UDim2.new(0.5, -80, 0.3, 0)
SmallDropGUI.BackgroundColor3 = Color3.fromRGB(30, 30, 35)
SmallDropGUI.BackgroundTransparency = 0.3
SmallDropGUI.BorderSizePixel = 0
SmallDropGUI.Active = true
SmallDropGUI.Parent = ScreenGui

local Corner = Instance.new("UICorner")
Corner.CornerRadius = UDim.new(0, 10)
Corner.Parent = SmallDropGUI

local Stroke = Instance.new("UIStroke")
Stroke.Color = Color3.fromRGB(138, 43, 226)
Stroke.Thickness = 2
Stroke.Parent = SmallDropGUI

-- Green/Gray Dot
local GreenDot = Instance.new("Frame")
GreenDot.Size = UDim2.new(0, 14, 0, 14)
GreenDot.Position = UDim2.new(0, 10, 0.5, -7)
GreenDot.BackgroundColor3 = Color3.fromRGB(100, 100, 100)
GreenDot.BorderSizePixel = 0
GreenDot.Parent = SmallDropGUI

local DotCorner = Instance.new("UICorner")
DotCorner.CornerRadius = UDim.new(1, 0)
DotCorner.Parent = GreenDot

-- Label
local Label = Instance.new("TextLabel")
Label.Size = UDim2.new(1, -75, 1, 0)
Label.Position = UDim2.new(0, 30, 0, 0)
Label.BackgroundTransparency = 1
Label.Text = "Drop Brainrot"
Label.TextColor3 = Color3.fromRGB(255, 255, 255)
Label.Font = Enum.Font.GothamBold
Label.TextSize = 12
Label.TextXAlignment = Enum.TextXAlignment.Left
Label.Parent = SmallDropGUI

-- Toggle Button (⚡ on right side)
local Button = Instance.new("TextButton")
Button.Size = UDim2.new(0, 45, 1, 0)
Button.Position = UDim2.new(1, -45, 0, 0)
Button.BackgroundTransparency = 1
Button.Text = "⚡"
Button.TextColor3 = Color3.fromRGB(138, 43, 226)
Button.Font = Enum.Font.GothamBold
Button.TextSize = 18
Button.ZIndex = 2
Button.Parent = SmallDropGUI

-- ═══════════════════════════════════════════════════════
-- SMOOTH DRAG SYSTEM
-- ═══════════════════════════════════════════════════════

local dragging = false
local dragInput = nil
local dragStart = nil
local startPos = nil
local targetX = SmallDropGUI.Position.X.Offset
local targetY = SmallDropGUI.Position.Y.Offset
local currentX = targetX
local currentY = targetY

RunService.RenderStepped:Connect(function()
    currentX = currentX + (targetX - currentX) * 0.18
    currentY = currentY + (targetY - currentY) * 0.18
    SmallDropGUI.Position = UDim2.new(
        SmallDropGUI.Position.X.Scale, math.round(currentX),
        SmallDropGUI.Position.Y.Scale, math.round(currentY)
    )
end)

SmallDropGUI.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
    or input.UserInputType == Enum.UserInputType.Touch then
        dragging = true
        dragStart = input.Position
        startPos = SmallDropGUI.Position
        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                dragging = false
            end
        end)
    end
end)

SmallDropGUI.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseMovement
    or input.UserInputType == Enum.UserInputType.Touch then
        dragInput = input
    end
end)

UserInputService.InputChanged:Connect(function(input)
    if input == dragInput and dragging then
        local delta = input.Position - dragStart
        targetX = startPos.X.Offset + delta.X
        targetY = startPos.Y.Offset + delta.Y
    end
end)

-- Toggle Logic
Button.MouseButton1Click:Connect(function()
    DropBrainrotEnabled = not DropBrainrotEnabled
    
    if DropBrainrotEnabled then
        SmallDropGUI.BackgroundColor3 = Color3.fromRGB(50, 200, 50)
        GreenDot.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
        startDropBrainrot()
        print("[DROP BRAINROT] ✅ ON - Auto-dropping every 5 seconds")
    else
        SmallDropGUI.BackgroundColor3 = Color3.fromRGB(30, 30, 35)
        GreenDot.BackgroundColor3 = Color3.fromRGB(100, 100, 100)
        stopDropBrainrot()
        print("[DROP BRAINROT] ⚪ OFF")
    end
end)
