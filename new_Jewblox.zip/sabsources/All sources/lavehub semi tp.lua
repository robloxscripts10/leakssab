-- LaveHub - Cleaned Script
-- ui: LaveHub env logged | logic full deobfed

local Players                = game:GetService("Players")
local TweenService           = game:GetService("TweenService")
local RunService             = game:GetService("RunService")
local UserInputService       = game:GetService("UserInputService")
local ProximityPromptService = game:GetService("ProximityPromptService")
local CoreGui                = game:GetService("CoreGui")
local ReplicatedStorage      = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer

-- ─── Positions ─────────────────────────────────────────────────────────────────

local pos1      = Vector3.new(-352.98, -7,    74.30)
local pos2      = Vector3.new(-352.98, -6.49, 45.76)
local standing1 = Vector3.new(-336.36, -4.59, 99.51)
local standing2 = Vector3.new(-334.81, -4.59, 18.90)

local spot1_sequence = {
    CFrame.new(-370.810913, -7.00000334, 41.2687263,  0.99984771, 1.22364419e-09, 0.0174523517, -6.54859778e-10, 1, -3.2596418e-08, -0.0174523517, 3.25800258e-08, 0.99984771),
    CFrame.new(-336.355286, -5.10107088, 17.2327671, -0.999883354, -2.76150569e-08, 0.0152716246, -2.88224964e-08, 1, -7.88441525e-08, -0.0152716246, -7.9275118e-08, -0.999883354)
}

local spot2_sequence = {
    CFrame.new(-354.782867, -7.00000334, 92.8209305, -0.999997616, -1.11891862e-09, -0.00218066527, -1.11958298e-09, 1, 3.03415071e-10, 0.00218066527, 3.05855785e-10, -0.999997616),
    CFrame.new(-336.942902, -5.10106993, 99.3276443,  0.999914348, -3.63984611e-08, 0.0130875716,   3.67094941e-08, 1, -2.35254749e-08, -0.0130875716, 2.40038975e-08, 0.999914348)
}

local autoSemiTpLeft  = CFrame.new(-349.325867, -7.00000238, 95.0031433, -0.999048233, -8.29406233e-09, -0.0436184891, -1.03892832e-08, 1, 4.78084594e-08,  0.0436184891, 4.82161227e-08, -0.999048233)
local autoSemiTpRight = CFrame.new(-349.560211, -7.00000238, 27.0543289, -0.999961913,  5.50995267e-08, -0.00872585084, 5.48100907e-08, 1, 3.34090586e-08,  0.00872585084, 3.29295204e-08, -0.999961913)

-- ─── State ─────────────────────────────────────────────────────────────────────

local semiTPEnabled   = false
local speedAfterSteal = false
local speedConnection = nil
local SPEED_BOOST     = 28

local IsStealing         = false
local StealProgress      = 0
local CurrentStealTarget = nil
local AUTO_STEAL_PROX_RADIUS = 200

local CONFIG = { ANTI_STEAL_ACTIVE = false }

local allAnimalsCache    = {}
local PromptMemoryCache  = {}
local InternalStealCache = {}

-- ─── FFlags + Desync ───────────────────────────────────────────────────────────

local function ResetToWork()
    local flags = {
        {"GameNetPVHeaderRotationalVelocityZeroCutoffExponent", "-5000"},
        {"LargeReplicatorWrite5", "true"},
        {"LargeReplicatorEnabled9", "true"},
        {"AngularVelociryLimit", "360"},
        {"TimestepArbiterVelocityCriteriaThresholdTwoDt", "2147483646"},
        {"S2PhysicsSenderRate", "15000"},
        {"DisableDPIScale", "true"},
        {"MaxDataPacketPerSend", "2147483647"},
        {"ServerMaxBandwith", "52"},
        {"PhysicsSenderMaxBandwidthBps", "20000"},
        {"MaxTimestepMultiplierBuoyancy", "2147483647"},
        {"SimOwnedNOUCountThresholdMillionth", "2147483647"},
        {"MaxMissedWorldStepsRemembered", "-2147483648"},
        {"CheckPVDifferencesForInterpolationMinVelThresholdStudsPerSecHundredth", "1"},
        {"StreamJobNOUVolumeLengthCap", "2147483647"},
        {"DebugSendDistInSteps", "-2147483648"},
        {"MaxTimestepMultiplierAcceleration", "2147483647"},
        {"LargeReplicatorRead5", "true"},
        {"SimExplicitlyCappedTimestepMultiplier", "2147483646"},
        {"GameNetDontSendRedundantNumTimes", "1"},
        {"CheckPVLinearVelocityIntegrateVsDeltaPositionThresholdPercent", "1"},
        {"CheckPVCachedRotVelThresholdPercent", "10"},
        {"LargeReplicatorSerializeRead3", "true"},
        {"ReplicationFocusNouExtentsSizeCutoffForPauseStuds", "2147483647"},
        {"NextGenReplicatorEnabledWrite4", "true"},
        {"CheckPVDifferencesForInterpolationMinRotVelThresholdRadsPerSecHundredth", "1"},
        {"GameNetDontSendRedundantDeltaPositionMillionth", "1"},
        {"InterpolationFrameVelocityThresholdMillionth", "5"},
        {"StreamJobNOUVolumeCap", "2147483647"},
        {"InterpolationFrameRotVelocityThresholdMillionth", "5"},
        {"WorldStepMax", "30"},
        {"TimestepArbiterHumanoidLinearVelThreshold", "1"},
        {"InterpolationFramePositionThresholdMillionth", "5"},
        {"TimestepArbiterHumanoidTurningVelThreshold", "1"},
        {"MaxTimestepMultiplierContstraint", "2147483647"},
        {"GameNetPVHeaderLinearVelocityZeroCutoffExponent", "-5000"},
        {"CheckPVCachedVelThresholdPercent", "10"},
        {"TimestepArbiterOmegaThou", "1073741823"},
        {"MaxAcceptableUpdateDelay", "1"},
        {"LargeReplicatorSerializeWrite4", "true"},
    }
    for _, data in ipairs(flags) do
        pcall(function() if setfflag then setfflag(data[1], data[2]) end end)
    end
    local char = player.Character
    if char then
        local hum = char:FindFirstChildOfClass("Humanoid")
        if hum then hum:ChangeState(Enum.HumanoidStateType.Dead) end
        char:ClearAllChildren()
        local f = Instance.new("Model", workspace)
        player.Character = f task.wait()
        player.Character = char f:Destroy()
    end
end

-- ─── Execute TP ────────────────────────────────────────────────────────────────

local function executeTP(sequence)
    local char    = player.Character
    local root    = char and char:FindFirstChild("HumanoidRootPart")
    local hum     = char and char:FindFirstChildOfClass("Humanoid")
    local backpack = player:FindFirstChild("Backpack")

    if root and hum and backpack then
        local carpet = backpack:FindFirstChild("Flying Carpet")
        if carpet then hum:EquipTool(carpet) end
        task.wait(0.05)
        root.CFrame = sequence[1]
        task.wait(0.1)
        root.CFrame = sequence[2]
    end
end

-- ─── Auto Steal Helpers ────────────────────────────────────────────────────────

local function getHRP()
    local char = player.Character
    if not char then return nil end
    return char:FindFirstChild("HumanoidRootPart") or char:FindFirstChild("UpperTorso")
end

local function isMyBase(plotName)
    local plot = workspace.Plots:FindFirstChild(plotName)
    if not plot then return false end
    local sign = plot:FindFirstChild("PlotSign")
    return sign and sign:FindFirstChild("YourBase") and sign.YourBase.Enabled
end

local function scanSinglePlot(plot)
    if not plot or not plot:IsA("Model") or isMyBase(plot.Name) then return end
    local podiums = plot:FindFirstChild("AnimalPodiums")
    if not podiums then return end
    for _, podium in ipairs(podiums:GetChildren()) do
        if podium:IsA("Model") and podium:FindFirstChild("Base") then
            table.insert(allAnimalsCache, {
                plot          = plot.Name,
                slot          = podium.Name,
                worldPosition = podium:GetPivot().Position,
                uid           = plot.Name .. "_" .. podium.Name,
            })
        end
    end
end

local function initializeScanner()
    task.wait(2)
    local plots = workspace:WaitForChild("Plots", 10)
    for _, plot in ipairs(plots:GetChildren()) do scanSinglePlot(plot) end
    plots.ChildAdded:Connect(scanSinglePlot)
    task.spawn(function()
        while task.wait(5) do
            table.clear(allAnimalsCache)
            for _, plot in ipairs(plots:GetChildren()) do scanSinglePlot(plot) end
        end
    end)
end

local function findPrompt(animal)
    local cached = PromptMemoryCache[animal.uid]
    if cached and cached.Parent then return cached end
    local plot   = workspace.Plots:FindFirstChild(animal.plot)
    local podium = plot and plot.AnimalPodiums:FindFirstChild(animal.slot)
    local prompt = podium and podium.Base.Spawn.PromptAttachment:FindFirstChildOfClass("ProximityPrompt")
    if prompt then PromptMemoryCache[animal.uid] = prompt end
    return prompt
end

local function buildStealCallbacks(prompt)
    if InternalStealCache[prompt] then return end
    local data = { holdCallbacks = {}, triggerCallbacks = {}, ready = true }
    local ok1, conns1 = pcall(getconnections, prompt.PromptButtonHoldBegan)
    if ok1 then
        for _, c in ipairs(conns1) do table.insert(data.holdCallbacks, c.Function) end
    end
    local ok2, conns2 = pcall(getconnections, prompt.Triggered)
    if ok2 then
        for _, c in ipairs(conns2) do table.insert(data.triggerCallbacks, c.Function) end
    end
    InternalStealCache[prompt] = data
end

local function executeInternalStealAsync(prompt, animalData)
    local data = InternalStealCache[prompt]
    if not data or not data.ready or IsStealing then return end
    data.ready = false
    IsStealing = true
    StealProgress = 0
    CurrentStealTarget = animalData
    local tpDone = false
    task.spawn(function()
        for _, fn in ipairs(data.holdCallbacks) do task.spawn(fn) end
        local startTime = tick()
        while tick() - startTime < 1.3 do
            StealProgress = (tick() - startTime) / 1.3
            if StealProgress >= 0.73 and not tpDone then
                tpDone = true
                local hrp = getHRP()
                if hrp then
                    hrp.CFrame = spot1_sequence[1]
                    task.wait(0.1)
                    hrp.CFrame = spot1_sequence[2]
                    task.wait(0.2)
                    local d1 = (hrp.Position - pos1).Magnitude
                    local d2 = (hrp.Position - pos2).Magnitude
                    hrp.CFrame = CFrame.new(d1 < d2 and pos1 or pos2)
                end
            end
            task.wait()
        end
        StealProgress = 1
        for _, fn in ipairs(data.triggerCallbacks) do task.spawn(fn) end
        task.wait(0.2)
        data.ready = true
        IsStealing = false
        StealProgress = 0
        CurrentStealTarget = nil
        CONFIG.ANTI_STEAL_ACTIVE = false
    end)
end

local function getNearestAnimal()
    local hrp = getHRP()
    if not hrp then return nil end
    local nearest, dist = nil, math.huge
    for _, animal in ipairs(allAnimalsCache) do
        local d = (hrp.Position - animal.worldPosition).Magnitude
        if d < dist and d <= AUTO_STEAL_PROX_RADIUS then
            dist = d
            nearest = animal
        end
    end
    return nearest
end

-- ─── ESP Markers ───────────────────────────────────────────────────────────────

local function createESPBox(position, labelText)
    local espFolder = Instance.new("Folder")
    espFolder.Name   = "ESPBox_" .. labelText
    espFolder.Parent = workspace

    local box = Instance.new("Part")
    box.Name         = "ESPPart"
    box.Size         = Vector3.new(5, 0.5, 5)
    box.Position     = position
    box.Anchored     = true
    box.CanCollide   = false
    box.Transparency = 0.5
    box.Material     = Enum.Material.Neon
    box.Color        = Color3.fromRGB(0, 0, 0)
    box.Parent       = espFolder

    local selectionBox = Instance.new("SelectionBox")
    selectionBox.Adornee       = box
    selectionBox.LineThickness = 0.05
    selectionBox.Color3        = Color3.fromRGB(255, 255, 255)
    selectionBox.Parent        = box

    local billboard = Instance.new("BillboardGui")
    billboard.Name        = "ESPLabel"
    billboard.Adornee     = box
    billboard.Size        = UDim2.new(0, 150, 0, 40)
    billboard.StudsOffset = Vector3.new(0, 2, 0)
    billboard.AlwaysOnTop = true
    billboard.Parent      = box

    local textLabel = Instance.new("TextLabel")
    textLabel.Size                   = UDim2.new(1, 0, 1, 0)
    textLabel.BackgroundTransparency = 1
    textLabel.Text                   = labelText
    textLabel.TextColor3             = Color3.fromRGB(255, 255, 255)
    textLabel.TextSize               = 18
    textLabel.Font                   = Enum.Font.GothamBold
    textLabel.TextStrokeTransparency = 0.5
    textLabel.TextStrokeColor3       = Color3.fromRGB(0, 0, 0)
    textLabel.Parent                 = billboard
end

createESPBox(pos1,                    "Teleport Here")
createESPBox(pos2,                    "Teleport Here")
createESPBox(standing1,               "Standing 1")
createESPBox(standing2,               "Standing 2")
createESPBox(autoSemiTpLeft.Position,  "Auto tp Left")
createESPBox(autoSemiTpRight.Position, "Auto tp Right")

-- ─── GUI ───────────────────────────────────────────────────────────────────────

if CoreGui:FindFirstChild("LaveHubGui") then
    CoreGui.LaveHubGui:Destroy()
end

local screenGui = Instance.new("ScreenGui")
screenGui.Name         = "LaveHubGui"
screenGui.ResetOnSpawn = false
screenGui.Parent       = CoreGui

-- Main card
local mainFrame = Instance.new("Frame")
mainFrame.Name                   = "MainFrame"
mainFrame.Size                   = UDim2.new(0, 240, 0, 380)
mainFrame.Position               = UDim2.new(0.5, -120, 0.5, -190)
mainFrame.BackgroundColor3       = Color3.fromRGB(18, 10, 10)
mainFrame.BorderSizePixel        = 0
mainFrame.Active                 = true
mainFrame.Draggable              = true
mainFrame.ClipsDescendants       = false
mainFrame.Parent                 = screenGui
Instance.new("UICorner", mainFrame).CornerRadius = UDim.new(0, 10)

-- Red shimmer border
local uiStroke = Instance.new("UIStroke", mainFrame)
uiStroke.Thickness = 2.5
uiStroke.Color     = Color3.fromRGB(200, 0, 0)

local uiGradient = Instance.new("UIGradient", uiStroke)
uiGradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0,    Color3.fromRGB(255, 0, 0)),
    ColorSequenceKeypoint.new(0.15, Color3.fromRGB(80,  0, 0)),
    ColorSequenceKeypoint.new(0.30, Color3.fromRGB(255, 0, 0)),
    ColorSequenceKeypoint.new(0.45, Color3.fromRGB(80,  0, 0)),
    ColorSequenceKeypoint.new(0.60, Color3.fromRGB(255, 0, 0)),
    ColorSequenceKeypoint.new(0.75, Color3.fromRGB(80,  0, 0)),
    ColorSequenceKeypoint.new(1,    Color3.fromRGB(255, 0, 0)),
})

task.spawn(function()
    while screenGui and screenGui.Parent do
        task.wait(0.03)
        uiGradient.Rotation = (uiGradient.Rotation + 2) % 360
    end
end)

-- Title
local title = Instance.new("TextLabel")
title.Size                   = UDim2.new(1, 0, 0, 36)
title.Position               = UDim2.new(0, 0, 0, 8)
title.BackgroundTransparency = 1
title.Text                   = "Lave Hub"
title.TextColor3             = Color3.fromRGB(220, 50, 50)
title.TextSize               = 22
title.Font                   = Enum.Font.GothamBlack
title.TextXAlignment         = Enum.TextXAlignment.Center
title.Parent                 = mainFrame

-- Divider
local divider = Instance.new("Frame")
divider.Size             = UDim2.new(1, -20, 0, 1)
divider.Position         = UDim2.new(0, 10, 0, 46)
divider.BackgroundColor3 = Color3.fromRGB(180, 30, 30)
divider.BorderSizePixel  = 0
divider.Parent           = mainFrame

-- Subtitle
local subtitle = Instance.new("TextLabel")
subtitle.Size                   = UDim2.new(1, 0, 0, 20)
subtitle.Position               = UDim2.new(0, 0, 0, 50)
subtitle.BackgroundTransparency = 1
subtitle.Text                   = "Lave Hub Half Tp"
subtitle.TextColor3             = Color3.fromRGB(200, 60, 60)
subtitle.TextSize               = 12
subtitle.Font                   = Enum.Font.Gotham
subtitle.TextXAlignment         = Enum.TextXAlignment.Center
subtitle.Parent                 = mainFrame

-- ─── Toggle Helper ─────────────────────────────────────────────────────────────

local function makeToggle(labelText, yPos, callback)
    local row = Instance.new("Frame")
    row.Size                   = UDim2.new(1, -20, 0, 32)
    row.Position               = UDim2.new(0, 10, 0, yPos)
    row.BackgroundTransparency = 1
    row.Parent                 = mainFrame

    local lbl = Instance.new("TextLabel")
    lbl.Size                   = UDim2.new(1, -50, 1, 0)
    lbl.BackgroundTransparency = 1
    lbl.Text                   = labelText
    lbl.TextColor3             = Color3.fromRGB(220, 220, 220)
    lbl.TextSize               = 14
    lbl.Font                   = Enum.Font.Gotham
    lbl.TextXAlignment         = Enum.TextXAlignment.Left
    lbl.Parent                 = row

    local pill = Instance.new("Frame")
    pill.Size             = UDim2.new(0, 40, 0, 22)
    pill.Position         = UDim2.new(1, -40, 0.5, -11)
    pill.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
    pill.BorderSizePixel  = 0
    pill.Parent           = row
    Instance.new("UICorner", pill).CornerRadius = UDim.new(1, 0)

    local knob = Instance.new("Frame")
    knob.Size             = UDim2.new(0, 18, 0, 18)
    knob.Position         = UDim2.new(0, 2, 0.5, -9)
    knob.BackgroundColor3 = Color3.fromRGB(200, 200, 200)
    knob.BorderSizePixel  = 0
    knob.Parent           = pill
    Instance.new("UICorner", knob).CornerRadius = UDim.new(1, 0)

    local enabled = false
    local btn = Instance.new("TextButton")
    btn.Size                   = UDim2.new(1, 0, 1, 0)
    btn.BackgroundTransparency = 1
    btn.Text                   = ""
    btn.Parent                 = pill

    btn.MouseButton1Click:Connect(function()
        enabled = not enabled
        if enabled then
            TweenService:Create(pill, TweenInfo.new(0.15), {BackgroundColor3 = Color3.fromRGB(180, 30, 30)}):Play()
            TweenService:Create(knob, TweenInfo.new(0.15), {Position = UDim2.new(1, -20, 0.5, -9)}):Play()
        else
            TweenService:Create(pill, TweenInfo.new(0.15), {BackgroundColor3 = Color3.fromRGB(60, 60, 60)}):Play()
            TweenService:Create(knob, TweenInfo.new(0.15), {Position = UDim2.new(0, 2, 0.5, -9)}):Play()
        end
        if callback then callback(enabled) end
    end)
end

-- ─── Toggles ───────────────────────────────────────────────────────────────────

makeToggle("Half Tp", 75, function(state)
    semiTPEnabled = state
end)

makeToggle("Auto Potion", 115, function(state)
    _G.AutoPotion = state
end)

makeToggle("Speed After Steal", 155, function(state)
    speedAfterSteal = state
    if not state and speedConnection then
        speedConnection:Disconnect()
        speedConnection = nil
    end
end)

-- ─── Big Button Helper ─────────────────────────────────────────────────────────

local function makeBigButton(labelText, yPos, onClick)
    local btn = Instance.new("TextButton")
    btn.Size             = UDim2.new(1, -20, 0, 40)
    btn.Position         = UDim2.new(0, 10, 0, yPos)
    btn.BackgroundColor3 = Color3.fromRGB(35, 10, 10)
    btn.TextColor3       = Color3.fromRGB(255, 255, 255)
    btn.Text             = labelText
    btn.TextSize         = 15
    btn.Font             = Enum.Font.GothamBold
    btn.BorderSizePixel  = 0
    btn.Parent           = mainFrame
    Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 8)

    local s = Instance.new("UIStroke", btn)
    s.Color     = Color3.fromRGB(160, 20, 20)
    s.Thickness = 1.5

    btn.MouseEnter:Connect(function()
        TweenService:Create(btn, TweenInfo.new(0.15), {BackgroundColor3 = Color3.fromRGB(100, 15, 15)}):Play()
    end)
    btn.MouseLeave:Connect(function()
        TweenService:Create(btn, TweenInfo.new(0.15), {BackgroundColor3 = Color3.fromRGB(35, 10, 10)}):Play()
    end)
    btn.MouseButton1Click:Connect(onClick)
    return btn
end

-- ─── Auto TP Left (auto steal spot1) ───────────────────────────────────────────

makeBigButton("Auto tp Left", 205, function()
    if IsStealing then return end
    CONFIG.ANTI_STEAL_ACTIVE = true
    local animal = getNearestAnimal()
    if not animal then return end
    local prompt = findPrompt(animal)
    if not prompt then return end
    buildStealCallbacks(prompt)
    executeInternalStealAsync(prompt, animal)
end)

-- ─── Auto TP Right (auto steal spot2) ──────────────────────────────────────────

makeBigButton("Auto tp Right", 253, function()
    if IsStealing then return end
    CONFIG.ANTI_STEAL_ACTIVE = true
    local animal = getNearestAnimal()
    if not animal then return end
    local prompt = findPrompt(animal)
    if not prompt then return end
    buildStealCallbacks(prompt)

    local data = InternalStealCache[prompt]
    if not data or not data.ready or IsStealing then return end
    data.ready = false
    IsStealing = true
    StealProgress = 0
    CurrentStealTarget = animal
    local tpDone = false

    task.spawn(function()
        for _, fn in ipairs(data.holdCallbacks) do task.spawn(fn) end
        local startTime = tick()
        while tick() - startTime < 1.3 do
            StealProgress = (tick() - startTime) / 1.3
            if StealProgress >= 0.73 and not tpDone then
                tpDone = true
                local hrp = getHRP()
                if hrp then
                    hrp.CFrame = spot2_sequence[1]
                    task.wait(0.1)
                    hrp.CFrame = spot2_sequence[2]
                    task.wait(0.2)
                    local d1 = (hrp.Position - pos1).Magnitude
                    local d2 = (hrp.Position - pos2).Magnitude
                    hrp.CFrame = CFrame.new(d1 < d2 and pos1 or pos2)
                end
            end
            task.wait()
        end
        StealProgress = 1
        for _, fn in ipairs(data.triggerCallbacks) do task.spawn(fn) end
        task.wait(0.2)
        data.ready = true
        IsStealing = false
        StealProgress = 0
        CurrentStealTarget = nil
        CONFIG.ANTI_STEAL_ACTIVE = false
    end)
end)

-- ─── Progress Bar ──────────────────────────────────────────────────────────────

local progressBg = Instance.new("Frame")
progressBg.Size             = UDim2.new(1, -20, 0, 14)
progressBg.Position         = UDim2.new(0, 10, 0, 301)
progressBg.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
progressBg.BorderSizePixel  = 0
progressBg.Parent           = mainFrame
Instance.new("UICorner", progressBg).CornerRadius = UDim.new(0, 4)

local fill = Instance.new("Frame")
fill.BackgroundColor3 = Color3.fromRGB(0, 170, 255)
fill.Size             = UDim2.new(0, 0, 1, 0)
fill.BorderSizePixel  = 0
fill.Parent           = progressBg
Instance.new("UICorner", fill).CornerRadius = UDim.new(0, 4)

local percentLabel = Instance.new("TextLabel")
percentLabel.Size                   = UDim2.new(1, -4, 1, 0)
percentLabel.BackgroundTransparency = 1
percentLabel.Text                   = "0%"
percentLabel.TextColor3             = Color3.fromRGB(255, 255, 255)
percentLabel.TextSize               = 10
percentLabel.Font                   = Enum.Font.GothamBold
percentLabel.TextXAlignment         = Enum.TextXAlignment.Right
percentLabel.Parent                 = progressBg

task.spawn(function()
    while true do
        fill.Size        = UDim2.new(math.clamp(StealProgress, 0, 1), 0, 1, 0)
        percentLabel.Text = math.floor(StealProgress * 100 + 0.5) .. "%"
        task.wait(0.02)
    end
end)

-- ─── TP TO SPOT Dropdown ───────────────────────────────────────────────────────

local dropdownContainer = Instance.new("Frame")
dropdownContainer.Name               = "DropdownContainer"
dropdownContainer.Size               = UDim2.new(1, -20, 0, 36)
dropdownContainer.Position           = UDim2.new(0, 10, 0, 322)
dropdownContainer.BackgroundTransparency = 1
dropdownContainer.ClipsDescendants   = true
dropdownContainer.Parent             = mainFrame

local dropdownButton = Instance.new("TextButton")
dropdownButton.Size             = UDim2.new(1, 0, 0, 36)
dropdownButton.BackgroundColor3 = Color3.fromRGB(35, 10, 10)
dropdownButton.Text             = "TP TO SPOT ▼"
dropdownButton.TextColor3       = Color3.fromRGB(255, 255, 255)
dropdownButton.TextSize         = 14
dropdownButton.Font             = Enum.Font.GothamBold
dropdownButton.BorderSizePixel  = 0
dropdownButton.Parent           = dropdownContainer
Instance.new("UICorner", dropdownButton).CornerRadius = UDim.new(0, 8)
local dbStroke = Instance.new("UIStroke", dropdownButton)
dbStroke.Color     = Color3.fromRGB(160, 20, 20)
dbStroke.Thickness = 1.5

local dropdownList = Instance.new("Frame")
dropdownList.Size                   = UDim2.new(1, 0, 0, 75)
dropdownList.Position               = UDim2.new(0, 0, 0, 40)
dropdownList.BackgroundTransparency = 1
dropdownList.Parent                 = dropdownContainer

local function createListButton(text, pos, callback)
    local btn = Instance.new("TextButton")
    btn.Size             = UDim2.new(1, 0, 0, 32)
    btn.Position         = pos
    btn.BackgroundColor3 = Color3.fromRGB(25, 8, 8)
    btn.Text             = text
    btn.TextColor3       = Color3.fromRGB(255, 255, 255)
    btn.TextSize         = 12
    btn.Font             = Enum.Font.GothamMedium
    btn.BorderSizePixel  = 0
    btn.Parent           = dropdownList
    Instance.new("UICorner", btn).CornerRadius = UDim.new(0, 6)
    btn.MouseButton1Click:Connect(function()
        callback()
        dropdownOpen = false
        dropdownContainer.Size = UDim2.new(1, -20, 0, 36)
        dropdownButton.Text    = "TP TO SPOT ▼"
    end)
end

createListButton("TP TO SPOT 1", UDim2.new(0, 0, 0, 0),  function() executeTP(spot1_sequence) end)
createListButton("TP TO SPOT 2", UDim2.new(0, 0, 0, 37), function() executeTP(spot2_sequence) end)

local dropdownOpen = false
dropdownButton.MouseButton1Click:Connect(function()
    dropdownOpen = not dropdownOpen
    local targetSize = dropdownOpen and UDim2.new(1, -20, 0, 115) or UDim2.new(1, -20, 0, 36)
    dropdownButton.Text = dropdownOpen and "TP TO SPOT ▲" or "TP TO SPOT ▼"
    TweenService:Create(dropdownContainer, TweenInfo.new(0.2), {Size = targetSize}):Play()
end)

-- ─── Discord Watermark ─────────────────────────────────────────────────────────

local discordText = Instance.new("TextLabel")
discordText.Size                   = UDim2.new(1, 0, 0, 15)
discordText.Position               = UDim2.new(0, 0, 1, -18)
discordText.BackgroundTransparency = 1
discordText.Text                   = "https://discord.gg/HVZXPf3PP"
discordText.TextColor3             = Color3.fromRGB(100, 100, 100)
discordText.TextSize               = 9
discordText.Font                   = Enum.Font.Gotham
discordText.TextXAlignment         = Enum.TextXAlignment.Center
discordText.Parent                 = mainFrame

-- ─── Proximity Prompt Hooks ────────────────────────────────────────────────────

local currentEquipTask = nil
local isHolding        = false

ProximityPromptService.PromptButtonHoldBegan:Connect(function(prompt, plr)
    if plr ~= player or not semiTPEnabled then return end
    isHolding = true
    if currentEquipTask then task.cancel(currentEquipTask) end
    currentEquipTask = task.spawn(function()
        task.wait(1)
        if isHolding and semiTPEnabled then
            local backpack = player:WaitForChild("Backpack", 2)
            if backpack then
                local carpet = backpack:FindFirstChild("Flying Carpet")
                if carpet and player.Character and player.Character:FindFirstChild("Humanoid") then
                    player.Character.Humanoid:EquipTool(carpet)
                end
            end
        end
    end)
end)

ProximityPromptService.PromptButtonHoldEnded:Connect(function(prompt, plr)
    if plr ~= player then return end
    isHolding = false
    if currentEquipTask then task.cancel(currentEquipTask) end
end)

ProximityPromptService.PromptTriggered:Connect(function(prompt, plr)
    if plr ~= player or not semiTPEnabled then return end
    local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
    if root then
        local d1 = (root.Position - pos1).Magnitude
        local d2 = (root.Position - pos2).Magnitude
        root.CFrame = CFrame.new(d1 < d2 and pos1 or pos2)

        if _G.AutoPotion then
            local backpack = player:FindFirstChild("Backpack")
            if backpack then
                local potion = backpack:FindFirstChild("Giant Potion")
                if potion and player.Character and player.Character:FindFirstChild("Humanoid") then
                    player.Character.Humanoid:EquipTool(potion)
                    task.wait(0.1)
                    pcall(function() potion:Activate() end)
                end
            end
        end

        if speedAfterSteal then
            local humanoid = player.Character:FindFirstChildOfClass("Humanoid")
            if humanoid then
                if speedConnection then speedConnection:Disconnect() end
                speedConnection = RunService.Heartbeat:Connect(function()
                    if not speedAfterSteal or humanoid.MoveDirection.Magnitude == 0 or not root.Parent then return end
                    local moveDir = humanoid.MoveDirection.Unit
                    root.AssemblyLinearVelocity = Vector3.new(moveDir.X * SPEED_BOOST, root.AssemblyLinearVelocity.Y, moveDir.Z * SPEED_BOOST)
                end)
            end
        end
    end
    isHolding = false
end)

-- ─── Init ──────────────────────────────────────────────────────────────────────

task.spawn(function()
    task.wait(1)
    ResetToWork()
end)

initializeScanner()