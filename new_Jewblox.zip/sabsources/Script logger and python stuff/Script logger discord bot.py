"""
bot.py
──────
Discord bot — .log / .list
 
The Lua logger body is embedded as base64 so it can never be corrupted
by Python string escaping.  base64.b64decode() returns the exact bytes every
time regardless of quotes, backslashes, or special characters in the Lua.
 
.log behaviour
──────────────
  User:    .log loadstring(game:HttpGet("https://..."))()`
  Output:  logged.txt = [full logger body]\n[user loadstring on last line]
"""
 
import asyncio
import base64
import io
import os
from datetime import datetime
 
import discord
import httpx
from discord import app_commands
from discord.ext import commands
 
# ─── Logger body (base64-encoded Lua) ─────────────────────────────────────────
# This is the exact hook logger script.  To update it:
#   import base64; print(base64.b64encode(open("new.lua","rb").read()).decode())
# Then replace the string below.
_LOGGER_BODY: str = base64.b64decode(
    "cHJpbnQoIlttYWRlIGJ5IHRva2lveCBvbiBkY10iKQp3cml0ZWZpbGUoJ2xvZ2dlZC50eHQnLCdc"
    "bmxvY2FsIFBsYXllcnMgPSBnYW1lOkdldFNlcnZpY2UoIlBsYXllcnMiKVxubG9jYWwgR2FtZVNl"
    "dHRpbmdzID0gZ2FtZTpHZXRTZXJ2aWNlKCJHYW1lU2V0dGluZ3MiKVxubG9jYWwgTG9jYWxpemF0"
    "aW9uU2VydmljZSA9IGdhbWU6R2V0U2VydmljZSgiTG9jYWxpemF0aW9uU2VydmljZSIpXG5sb2Nh"
    "bCBXZWJTb2NrZXRTZXJ2aWNlID0gZ2FtZTpHZXRTZXJ2aWNlKCJXZWJTb2NrZXRTZXJ2aWNlIilc"
    "bmxvY2FsIFdlYlNvY2tldENsaWVudCA9IGdhbWU6R2V0U2VydmljZSgiV2ViU29ja2V0Q2xpZW50"
    "IilcbmxvY2FsIEh0dHBTZXJ2aWNlID0gZ2FtZTpHZXRTZXJ2aWNlKCJIdHRwU2VydmljZSIpXG5s"
    "b2NhbCBVc2VySW5wdXRTZXJ2aWNlID0gZ2FtZTpHZXRTZXJ2aWNlKCJVc2VySW5wdXRTZXJ2aWNl"
    "IilcbmxvY2FsIFJ1blNlcnZpY2UgPSBnYW1lOkdldFNlcnZpY2UoIlJ1blNlcnZpY2UiKVxubG9j"
    "YWwgVGVsZXBvcnRTZXJ2aWNlID0gZ2FtZTpHZXRTZXJ2aWNlKCJUZWxlcG9ydFNlcnZpY2UiKVxu"
    "JykKCmxvY2FsIGZ1bmN0aW9uIGlzdWlsaWIoKQogbG9jYWwgYSA9IGRlYnVnLnRyYWNlYmFjaygp"
    "CiBsb2NhbCBiID0gYTpsb3dlcigpOmdzdWIoJyVzKycsJycpCiByZXR1cm4gYjpmaW5kKCd3aW5k"
    "dWknKSBvciBiOmZpbmQoJ3JheWZpZWxkJykgb3IgYjpmaW5kKCdvYnNpZGlhbicpIG9yIGI6Zmlu"
    "ZCgnaW50ZXJmYWNlJykgb3IgYjpmaW5kKCdsdW5hJykgb3IgYjpmaW5kKCdmbHVlbnQnKSBvciBi"
    "OmZpbmQoJ2RyZGF5JykKZW5kCgpsb2NhbCBmdW5jdGlvbiBmb3JtYXRsb2codGV4dCkKIGlmIHR5"
    "cGUodGV4dCkgfj0gJ3N0cmluZycgdGhlbgogIGVycm9yKCdCYWQgYWdydW1lbnQgIzEgdG8gZm9y"
    "bWF0bG9nICJzdHJpbmciIGV4cGVjdGVkLCBnb3Q6ICcuLnR5cGUodGV4dCkpCiAgcmV0dXJuCiBl"
    "bmQKIHJldHVybiB0ZXh0OmdzdWIoJ3RhYmxlOiAnLCcnKTpnc3ViKCdmdW5jdGlvbjogJywnJyk6"
    "Z3N1YignVWdjJywnZ2FtZScpOmdzdWIoJ1xuJywnJyk6Z3N1YignJXMlcysnLCc7Jyk6Z3N1Yign"
    "IiInLCcnKTpnc3ViKCdEYXRhIFBpbmcnLCAnRGF0YVBpbmcnKTpnc3ViKCdXb3Jrc3BhY2UnLCd3"
    "b3Jrc3BhY2UnKTpnc3ViKCdnYW1lLlBsYXllcnMnLCdQbGF5ZXJzJyk6Z3N1YignVGVsZXBvcnQg"
    "U2VydmljZScsJ1RlbGVwb3J0U2VydmljZScpOmdzdWIoJ1J1biBTZXJ2aWNlJywnUnVuU2Vydmlj"
    "ZScpOmdzdWIoJ0h0dHBHZXRBc3luYycsJ0h0dHBHZXQnKTpnc3ViKCciJywiJyIpCmVuZAoKbG9j"
    "YWwgZnVuY3Rpb24gdGJsZm9ybWF0KHRibCwgZGVwdGgpCiBsb2NhbCBkZXB0aCA9IGRlcHRoIG9y"
    "IDAKIGxvY2FsIHJlcyA9ICcnCiBsb2NhbCBmaXJzdCA9IHRydWUKIGlmIGRlcHRoID4gNSB0aGVu"
    "IHJldHVybiAndG9vIGJpZyB0byBkaXNwbGF5JyBlbmQKIGlmIHR5cGUodGJsKSB+PSAndGFibGUn"
    "IHRoZW4KICByZXMgPSAnIicuLnRvc3RyaW5nKHRibCkuLiciJwogIGlmIHJlcyA9PSAnIm5pbCIn"
    "IHRoZW4KICAgcmVzID0gJycKICBlbmQKICByZXR1cm4gcmVzCiBlbmQKIGZvciBpLCB2IGluIHBh"
    "aXJzKHRibCkgZG8KICBpZiBub3QgZmlyc3QgdGhlbiByZXMgPSByZXMgLi4gJywgJyBlbmQKICBm"
    "aXJzdCA9IGZhbHNlCiAgaWYgdHlwZShpKSA9PSAnc3RyaW5nJyB0aGVuCiAgIHJlcyA9IHJlcyAu"
    "LiBpIC4uICcgPSAnCiAgZW5kCiAgaWYgdHlwZShpKSA9PSAndGFibGUnIHRoZW4KICAgcmVzID0g"
    "cmVzIC4uIHRibGZvcm1hdCh2LCBkZXB0aCArIDEpCiAgZWxzZQogICByZXMgPSByZXMgLi4gdG9z"
    "dHJpbmcodikKICBlbmQKIGVuZAogcmV0dXJuIHJlcyAuLiAnJwplbmQKCmxvY2FsIFRyYWNrID0g"
    "e30KbG9jYWwga2lya2VkID0ge30KbG9jYWwgZnVuY3Rpb24ga2lyayhmZW0sIGJveSkKIHJldHVy"
    "biBmZW0gLi4gJzsnIC4uIGJveQplbmQKbG9jYWwgY2FjaGUgPSAnJwpsb2NhbCB1cHZhbHNjYWNo"
    "ZSA9ICcnCmxvY2FsIGZvcm1hdGVkY2FjaGUgPSAnJwpsb2NhbCBsb2djb3VudCA9IDEKbG9jYWwg"
    "ZnVuY3Rpb24gbG9nKHVwdmFscywgLi4uKQogdXB2YWxzID0gdXB2YWxzIG9yICduaWwnCiB1cHZh"
    "bHMgPSBmb3JtYXRsb2codG9zdHJpbmcodXB2YWxzKSkKIGlmICN1cHZhbHMgPiAxMDAgdGhlbgog"
    "IGxvY2FsIGhvbGRlciA9ICN1cHZhbHMKICB1cHZhbHMgPSB1cHZhbHM6c3ViKDEsNTApIC4uICcu"
    "Li4gKCcgLi4gaG9sZGVyIC4uICcgY2hhcmFjdGVyIHJlbWFpbmluZyknCiBlbmQKIGxvY2FsIGFy"
    "Z3MgPSAuLi4KIGxvY2FsIGZvcm1hdGVkID0gZm9ybWF0bG9nKHRvc3RyaW5nKGFyZ3MpKQogbG9j"
    "YWwgbG9nZ2VkID0gZm9ybWF0ZWQKIGlmIGxvZ2dlZCA9PSBjYWNoZSB0aGVuCiAgcmV0dXJuCiBl"
    "bmQKIGlmIGZvcm1hdGVkID09IGZvcm1hdGVkY2FjaGUgYW5kIHVwdmFscyA9PSB1cHZhbHNjYWNo"
    "ZSB0aGVuCiAgcmV0dXJuCiBlbmQKIGxvY2FsIGNoYXJsaWVraXJrID0ga2lyayhsb2dnZWQsIHVw"
    "dmFscykKIGlmIGtpcmtlZFtjaGFybGlla2lya10gdGhlbgogIHJldHVybgogZW5kCiBpZiB1cHZh"
    "bHM6ZmluZCgnU2lnbmFsJykgdGhlbgogIGxvZ2dlZCA9IGZvcm1hdGVkIC4uICc6Q29ubmVjdChm"
    "dW5jdGlvbiguLi4pZW5kKScKIGVuZAogaWYgbG9nZ2VkOmZpbmQoJ2dhbWU6SHR0cEdldCcpIHRo"
    "ZW4KICBsb2dnZWQgPSAnbG9hZHN0cmluZygnLi5mb3JtYXRlZC4uJykoKScKIGVuZAogaWYgbG9n"
    "Y291bnQgPiAzNjAwMCB0aGVuCiAgZ2FtZTpzaHV0ZG93bigpCiAgcmV0dXJuCiBlbmQKIGlmIGxv"
    "Z2dlZDpmaW5kKCdJc0EnKSB0aGVuCiAgcmV0dXJuCiBlbmQKIGxvZ2NvdW50ICs9IDEKIGNhY2hl"
    "ID0gbG9nZ2VkCiB1cHZhbHNjYWNoZSA9IHVwdmFscwogZm9ybWF0ZWRjYWNoZSA9IGZvcm1hdGVk"
    "CiBraXJrZWRbY2hhcmxpZWtpcmtdID0gdHJ1ZQogYXBwZW5kZmlsZSgnbG9nZ2VkLnR4dCcsbG9n"
    "Z2VkLi4nXG4nKQplbmQKCmlzZnVuY3Rpb25ob29rZWQgPSBuaWwKcmVzdG9yZWZ1bmN0aW9uID0g"
    "bmlsCgpmdW5jdGlvbiBHbG9iYWxTY2FuKCkKIGZvciBpLCB2IGluIHBhaXJzKF9HKSBkbwogIGxv"
    "ZygnX0cgU2NhbicsICdfRy4nLi5pLi4nID0gJy4udGJsZm9ybWF0KHYpKQogZW5kCmVuZAoKZnVu"
    "Y3Rpb24gR2VudlNjYW4oKQogZm9yIGksIHYgaW4gcGFpcnMoZ2V0Z2VudigpKSBkbwogIGxvZygn"
    "Z2V0Z2VudiBTY2FuJywgJ2dldGdlbnYoKS4nLi5pLi4nID0gJy4udGJsZm9ybWF0KHYpKQogZW5k"
    "CmVuZAoKbG9jYWwgb2xkc2V0ZmZsYWcgPSBjbG9uZWZ1bmN0aW9uKHNldGZmbGFnKQpzZXRmZmxh"
    "ZyA9IG5ld2NjbG9zdXJlKGZ1bmN0aW9uKGZsYWcsIHN0YXRlKQogbG9jYWwgdXB2YWxzID0gb2xk"
    "c2V0ZmZsYWcoZmxhZywgc3RhdGUpCiBsb2codXB2YWxzLCdzZXRmZmxhZygiJy4uZmxhZy4uJyIs"
    "ICcuLiciJy4uc3RhdGUuLiciKScpCiByZXR1cm4gdXB2YWxzCmVuZCkKCmlmIGh0dHAgYW5kIGh0"
    "dHAucmVxdWVzdCB0aGVuCiBzZXRyZWFkb25seShodHRwLCBmYWxzZSkKIGh0dHAucmVxdWVzdCA9"
    "IG5pbAogc2V0cmVhZG9ubHkoaHR0cCwgZmFsc2UpCmVuZApsb2NhbCBvbGRyZXF1ZXN0ID0gcmVx"
    "dWVzdApyZXF1ZXN0ID0gbmV3Y2Nsb3N1cmUoZnVuY3Rpb24oZGF0YSkKIGxvY2FsIHVwdmFscyA9"
    "IG9sZHJlcXVlc3QoZGF0YSkKIGxvY2FsIG1lb3cgPSBkYXRhLkJvZHkKIGlmIHR5cGUoZGF0YS5C"
    "b2R5KSA9PSAnc3RyaW5nJyB0aGVuCiAgaWYgZGF0YS5Cb2R5OnN1YigxLDEpID09ICd7JyBhbmQg"
    "ZGF0YS5Cb2R5OnN1YigtMSkgPT0gJ30nIHRoZW4KICAgbWVvdyA9IGRhdGEuQm9keQogIGVsc2UK"
    "ICAgbWVvdyA9ICciJy4uZGF0YS5Cb2R5Li4nIicKICBlbmQKIGVsc2VpZiB0eXBlKGRhdGEuQm9k"
    "eSkgPT0gJ3RhYmxlJyB0aGVuCiAgbWVvdyA9ICdnYW1lOkdldFNlcnZpY2UoIkh0dHBTZXJ2aWNl"
    "Iik6SlNPTkVuY29kZSgnLi50Ymxmb3JtYXQoZGF0YS5Cb2R5KS4uJyknCiBlbHNlCiAgbWVvdyA9"
    "IHRvc3RyaW5nKGRhdGEuQm9keSkKIGVuZAogbG9jYWwgbWVvd21lb3cgPSAneycKIGxvY2FsIGZp"
    "cnN0ID0gdHJ1ZQogaWYgZGF0YS5IZWFkZXJzIHRoZW4KICBmb3IgaSwgdiBpbiBwYWlycyhkYXRh"
    "LkhlYWRlcnMpIGRvCiAgIGlmIG5vdCBmaXJzdCB0aGVuIG1lb3dtZW93ID0gbWVvd21lb3cgLi4g"
    "JywgJyBlbmQKICAgZmlyc3QgPSBmYWxzZQogICBtZW93bWVvdyA9IG1lb3dtZW93IC4uICdbIicu"
    "LmkuLiciXSA9ICInLi52Li4nIicKICBlbmQKIGVuZAogbWVvd21lb3cgPSBtZW93bWVvdyAuLiAn"
    "fScKIGxvZyh1cHZhbHMsICdyZXF1ZXN0KHtcbiBVcmwgPSAiJy4uZGF0YS5VcmwuLiciLFxuIE1l"
    "dGhvZCA9ICInLi5kYXRhLk1ldGhvZC4uJyIsXG4gQm9keSA9ICcuLm1lb3cuLicsXG4gSGVhZGVy"
    "cyA9ICcuLm1lb3dtZW93Li4nXG59KScpCiByZXR1cm4gdXB2YWxzCmVuZCkKCmxvY2FsIG9sZGwg"
    "PSBjbG9uZWZ1bmN0aW9uKGxvYWRzdHJpbmcpCmhvb2tmdW5jdGlvbihsb2Fkc3RyaW5nLCBmdW5j"
    "dGlvbihzdHIpCiBpZiB0cnVlIHRoZW4KICB3cml0ZWZpbGUobWF0aC5yYW5kb20oMSw5OTkpLi4n"
    "LnR4dCcsIHN0cikKICB3YXJuJ3hkJwogZW5kCiByZXR1cm4gb2xkbChzdHIpCmVuZCkKCmxvY2Fs"
    "IHdzcyA9IGdhbWU6R2V0U2VydmljZSgnV2ViU29ja2V0U2VydmljZScpCmxvY2FsIG9sZHdzc2Nj"
    "ID0gY2xvbmVmdW5jdGlvbih3c3MuQ3JlYXRlQ2xpZW50KQpob29rZnVuY3Rpb24oZ2FtZS5XZWJT"
    "b2NrZXRTZXJ2aWNlLkNyZWF0ZUNsaWVudCwgZnVuY3Rpb24oXywgdXJsKQogd2FybignV1NTJykK"
    "IGlmIG5vdCB1cmw6bG93ZXIoKTpmaW5kJ2x1YXJtb3InIHRoZW4KICBsb2coJ2lkayBpIGZvdW5k"
    "IGx1YXJtb3IgdXNlIHRoaXMgeGQnLCAnV2Vic29ja2V0U2VydmljZTpDcmVhdGVDbGllbnQoIldl"
    "YlNvY2tldFNlcnZpY2UiLCInLi51cmwuLiciKScpCiBlbmQKIHJldHVybiBvbGR3c3NjYyhfLCB1"
    "cmwpCmVuZCkKCkluc3RhbmNlID0gSW5zdGFuY2Ugb3Ige30KbG9jYWwgb2xkaW5zdGFuY2VuZXcg"
    "PSBjbG9uZWZ1bmN0aW9uKEluc3RhbmNlLm5ldykKc2V0cmVhZG9ubHkoSW5zdGFuY2UsIGZhbHNl"
    "KQpJbnN0YW5jZS5uZXcgPSBuZXdjY2xvc3VyZShmdW5jdGlvbihuYW1lLCBwYXJlbnQpCiBpZiBj"
    "aGVja2NhbGxlcigpIGFuZCBub3QgaXN1aWxpYigpIHRoZW4KICBsb2NhbCB1cHZhbHMgPSBvbGRp"
    "bnN0YW5jZW5ldyhuYW1lLCBwYXJlbnQpCiAgbG9jYWwgYSA9IGRlYnVnLmdldGluZm8oMiwnU2wn"
    "KQogIGlmIGEgYW5kIGEuc291cmNlOmZpbmQoJ0AnKSB0aGVuCiAgIGxvZyh1cHZhbHMsICdsb2Nh"
    "bCBhID0gSW5zdGFuY2UubmV3KCInLi5uYW1lLi4nIiknKQogIGVsc2UKICAgbG9jYWwgYiA9IHRv"
    "c3RyaW5nKG5hbWUpCiAgIFRyYWNrW3VwdmFsc10gPSBiCiAgIGxvZyh1cHZhbHMsICdsb2NhbCAn"
    "Li5iLi4nID0gSW5zdGFuY2UubmV3KCInLi5uYW1lLi4nIiknKQogIGVuZAogIHJldHVybiB1cHZh"
    "bHMKIGVuZAogcmV0dXJuIG9sZGluc3RhbmNlbmV3KG5hbWUsIHBhcmVudCkKZW5kKQoKbG9jYWwg"
    "bXQgPSBnZXRyYXdtZXRhdGFibGUoZ2FtZSkKbG9jYWwgb2xkaW5kZXggPSBjbG9uZWZ1bmN0aW9u"
    "KG10Ll9faW5kZXgpCmxvY2FsIG9sZG5hbWVjYWxsID0gY2xvbmVmdW5jdGlvbihtdC5fX25hbWVj"
    "YWxsKQpsb2NhbCBvbGRuZXdpbmRleCA9IGNsb25lZnVuY3Rpb24obXQuX19uZXdpbmRleCkKaG9v"
    "a21ldGFtZXRob2QoZ2FtZSwnX19pbmRleCcsbmV3Y2Nsb3N1cmUoZnVuY3Rpb24oc2VsZiwgdiwg"
    "Li4uKQogaWYgY2hlY2tjYWxsZXIoKSBhbmQgbm90IGlzdWlsaWIoKSB0aGVuCiAgbG9jYWwgdXB2"
    "YWxzID0gb2xkaW5kZXgoc2VsZiwgdiwgLi4uKQogIGxvY2FsIGZvcm1hdGVkID0gdGJsZm9ybWF0"
    "KC4uLikKICBpZiB2ID09ICdDaGFyYWN0ZXInIHRoZW4KICAgbG9nKCdMb2NhbFBsYXllci5DaGFy"
    "YWN0ZXInLCBzZWxmOkdldEZ1bGxOYW1lKCkuLicuJy4udikKICAgcmV0dXJuIHVwdmFscwogIGVu"
    "ZAogIGlmIHYgPT0gJ0dldFNlcnZpY2UnIHRoZW4gcmV0dXJuIHVwdmFscyBlbmQKICBpZiB2ID09"
    "ICdIdHRwR2V0JyB0aGVuIHJldHVybiB1cHZhbHMgZW5kCiAgaWYgdiA9PSAnSlNPTkRlY29kZScg"
    "dGhlbiByZXR1cm4gdXB2YWxzIGVuZAogIGlmIHYgPT0gJ0NvcmVHdWknIHRoZW4gcmV0dXJuIHVw"
    "dmFscyBlbmQKICBpZiB2ID09ICdKU09ORW5jb2RlJyB0aGVuIHJldHVybiB1cHZhbHMgZW5kCiAg"
    "aWYgdiA9PSAnSm9iSWQnIHRoZW4gbG9nKCdnYW1lLkpvYklkJywgc2VsZjpHZXRGdWxsTmFtZSgp"
    "Li4nLicuLnYpIHJldHVybiB1cHZhbHMgZW5kCiAgaWYgdiA9PSAnUGxhY2VJZCcgdGhlbiBsb2co"
    "J2dhbWUuUGxhY2VJZCcsIHNlbGY6R2V0RnVsbE5hbWUoKS4uJy4nLi52KSByZXR1cm4gdXB2YWxz"
    "IGVuZAogIGlmIHYgPT0gJ1dhaXRGb3JDaGlsZCcgdGhlbiByZXR1cm4gdXB2YWxzIGVuZAogIGlm"
    "IHYgPT0gJ0ZpbmRGaXJzdENoaWxkJyB0aGVuIHJldHVybiB1cHZhbHMgZW5kCiAgaWYgdiA9PSAn"
    "RGVzY2VuZGFudFJlbW92aW5nJyB0aGVuIHJldHVybiB1cHZhbHMgZW5kCiAgaWYgdG9zdHJpbmco"
    "dXB2YWxzKTpmaW5kKCdmdW5jdGlvbjonKSB0aGVuCiAgIGxvZyh1cHZhbHMsIHNlbGY6R2V0RnVs"
    "bE5hbWUoKS4uJzonLi52Li4nKCcuLmZvcm1hdGVkLi4nKScpCiAgIHJldHVybiB1cHZhbHMKICBl"
    "bmQKICBsb2codXB2YWxzLCBzZWxmOkdldEZ1bGxOYW1lKCkuLicuJy4udikKICByZXR1cm4gdXB2"
    "YWxzCiBlbmQKIHJldHVybiBvbGRpbmRleChzZWxmLCB2LCAuLi4pCmVuZCkpCmhvb2ttZXRhbWV0"
    "aG9kKGdhbWUsICdfX25hbWVjYWxsJywgbmV3Y2Nsb3N1cmUoZnVuY3Rpb24oc2VsZiwgLi4uKQog"
    "aWYgY2hlY2tjYWxsZXIoKSBhbmQgbm90IGlzdWlsaWIoKSBhbmQgZ2V0bmFtZWNhbGxtZXRob2Qo"
    "KSB+PSAnR2V0RnVsbE5hbWUnIHRoZW4KICBsb2NhbCBpbnN0YW5jZSA9IHRvc3RyaW5nKHNlbGYp"
    "CiAgaWYgdHlwZShpbnN0YW5jZSkgPT0gJ0luc3RhbmNlJyB0aGVuCiAgIGluc3RhbmNlID0gb2xk"
    "bmFtZWNhbGwoaW5zdGFuY2UsICdHZXRGdWxsTmFtZScpCiAgZW5kCiAgbG9jYWwgdXB2YWxzID0g"
    "b2xkbmFtZWNhbGwoc2VsZiwgLi4uKQogIGxvY2FsIGFyZ3MgPSB7Li4ufQogIGxvY2FsIGZvcm1h"
    "dGVkID0gdGJsZm9ybWF0KGFyZ3MpCiAgaWYgZ2V0bmFtZWNhbGxtZXRob2QoKSA9PSAnR2V0U2Vy"
    "dmljZScgdGhlbgogICBsb2codXB2YWxzLCAnZ2FtZTpHZXRTZXJ2aWNlKCInLi5hcmdzWzFdLi4n"
    "IiknKQogICByZXR1cm4gdXB2YWxzCiAgZW5kCiAgaWYgZ2V0bmFtZWNhbGxtZXRob2QoKSA9PSAn"
    "V2FpdEZvckNoaWxkJyB0aGVuCiAgIGxvZyh1cHZhbHMsIGluc3RhbmNlLi4nOldhaXRGb3JDaGls"
    "ZCgiJy4uYXJnc1sxXS4uJyIpJykKICAgcmV0dXJuIHVwdmFscwogIGVuZAogIGlmIGdldG5hbWVj"
    "YWxsbWV0aG9kKCkgPT0gJ0ZpbmRGaXJzdENoaWxkJyB0aGVuCiAgIGxvZyh1cHZhbHMsIGluc3Rh"
    "bmNlLi4nOkZpbmRGaXJzdENoaWxkKCInLi5hcmdzWzFdLi4nIiknKQogICByZXR1cm4gdXB2YWxz"
    "CiAgZW5kCiAgaWYgZ2V0bmFtZWNhbGxtZXRob2QoKSA9PSAnSHR0cEdldCcgdGhlbgogICBsb2co"
    "dXB2YWxzLCAnZ2FtZTpIdHRwR2V0KCInLi5hcmdzWzFdLi4nIiwgdHJ1ZSknKQogICByZXR1cm4g"
    "dXB2YWxzCiAgZW5kCiAgbG9nKHVwdmFscywgaW5zdGFuY2UuLic6Jy4uZ2V0bmFtZWNhbGxtZXRo"
    "b2QoKS4uJygiJy4uZm9ybWF0ZWQuLiciKScpCiAgcmV0dXJuIHVwdmFscwogZW5kCiByZXR1cm4g"
    "b2xkbmFtZWNhbGwoc2VsZiwgLi4uKQplbmQpKQpob29rbWV0YW1ldGhvZChnYW1lLCAnX19uZXdp"
    "bmRleCcsIG5ld2NjbG9zdXJlKGZ1bmN0aW9uKHNlbGYsIGksIHYpCiBpZiBjaGVja2NhbGxlcigp"
    "IGFuZCBub3QgaXN1aWxpYigpIHRoZW4KICBsb2NhbCB1cHZhbHMgPSBvbGRuZXdpbmRleChzZWxm"
    "LCBpLCB2KQogIGxvY2FsIGEgPSBUcmFja1tzZWxmXQogIGxvY2FsIGIgPSB0b3N0cmluZyhpKQog"
    "IGxvY2FsIGMgPSB0b3N0cmluZyh0eXBlb2YodikpIG9yICdVbmtub3duJwogIGxvY2FsIGQgPSB0"
    "b3N0cmluZyh2KQogIGlmIGEgdGhlbgogICBpZiBiIHRoZW4KICAgIGlmIGMgPT0gJ0luc3RhbmNl"
    "JyB0aGVuCiAgICAgbG9nKHVwdmFscywgYS4uJy4nLi5iLi4nID0gJy4udjpHZXRGdWxsTmFtZSgp"
    "KQogICAgZWxzZWlmIGMgPT0gJ251bWJlcicgdGhlbgogICAgIGxvZyh1cHZhbHMsIGEuLicuJy4u"
    "Yi4uJyA9ICcuLmQpCiAgICBlbHNlaWYgYyA9PSAnc3RyaW5nJyB0aGVuCiAgICAgbG9nKHVwdmFs"
    "cywgYS4uJy4nLi5iLi4nID0gIicuLmQuLiciJykKICAgIGVsc2VpZiBjID09ICdib29sZWFuJyB0"
    "aGVuCiAgICAgbG9nKHVwdmFscywgYS4uJy4nLi5iLi4nID0gJy4uZCkKICAgIGVsc2VpZiBjID09"
    "ICdDb2xvcjMnIHRoZW4KICAgICBsb2codXB2YWxzLCBhLi4nLicuLmIuLicgPSBDb2xvcjMubmV3"
    "KCcuLmQuLicpJykKICAgIGVsc2VpZiBjID09ICdDRnJhbWUnIHRoZW4KICAgICBsb2codXB2YWxz"
    "LCBhLi4nLicuLmIuLicgPSBDRnJhbWUubmV3KCcuLmQuLicpJykKICAgIGVsc2VpZiBjID09ICdW"
    "ZWN0b3IzJyB0aGVuCiAgICAgbG9nKHVwdmFscywgYS4uJy4nLi5iLi4nID0gVmVjdG9yMy5uZXco"
    "Jy4uZC4uJyknKQogICAgZWxzZWlmIGMgPT0gJ1VEaW0yJyB0aGVuCiAgICAgbG9nKHVwdmFscywg"
    "YS4uJy4nLi5iLi4nID0gVURpbTIubmV3KCcuLmQ6Z3N1YigneycsJycpOmdzdWIoJ30nLCcnKS4u"
    "JyknKQogICAgZWxzZWlmIGMgPT0gJ1ZlY3RvcjInIHRoZW4KICAgICBsb2codXB2YWxzLCBhLi4n"
    "LicuLmIuLicgPSBWZWN0b3IyLm5ldygnLi5kLi4nKScpCiAgICBlbHNlaWYgYyA9PSAnVURpbScg"
    "dGhlbgogICAgIGxvZyh1cHZhbHMsIGEuLicuJy4uYi4uJyA9IFVEaW0ubmV3KCcuLmQuLicpJykK"
    "ICAgIGVsc2VpZiBjID09ICdFbnVtSXRlbScgdGhlbgogICAgIGxvZyh1cHZhbHMsIGEuLicuJy4u"
    "Yi4uJyA9ICcuLmQpCiAgICBlbHNlaWYgYyA9PSAnQ29sb3JTZXF1ZW5jZScgdGhlbgogICAgIGxv"
    "Zyh1cHZhbHMsIGEuLicuJy4uYi4uJyA9IENvbG9yU2VxdWVuY2UubmV3KCcuLmQ6Z3N1YignJXMr"
    "JywnLCcpLi4nKScpCiAgICBlbHNlCiAgICAgbG9nKHVwdmFscywgYS4uJy4nLi5iLi4nID0gJy4u"
    "J1snLi5jLi4nXSAnLi5kKQogICAgZW5kCiAgIGVuZAogIGVsc2UKICAgaWYgYiB0aGVuCiAgICBp"
    "ZiBjID09ICdJbnN0YW5jZScgdGhlbgogICAgIGxvZyh1cHZhbHMsICdhLicuLmIuLicgPSAnLi52"
    "OkdldEZ1bGxOYW1lKCkpCiAgICBlbHNlaWYgYyA9PSAnbnVtYmVyJyB0aGVuCiAgICAgbG9nKHVw"
    "dmFscywgJ2EuJy4uYi4uJyA9ICcuLmQpCiAgICBlbHNlaWYgYyA9PSAnc3RyaW5nJyB0aGVuCiAg"
    "ICAgbG9nKHVwdmFscywgJ2EuJy4uYi4uJyA9ICInLi5kLi4nIicpCiAgICBlbHNlaWYgYyA9PSAn"
    "Ym9vbGVhbicgdGhlbgogICAgIGxvZyh1cHZhbHMsICdhLicuLmIuLicgPSAnLi5kKQogICAgZWxz"
    "ZWlmIGMgPT0gJ0NvbG9yMycgdGhlbgogICAgIGxvZyh1cHZhbHMsICdhLicuLmIuLicgPSBDb2xv"
    "cjMubmV3KCcuLmQuLicpJykKICAgIGVsc2VpZiBjID09ICdDRnJhbWUnIHRoZW4KICAgICBsb2co"
    "dXB2YWxzLCAnYS4nLi5iLi4nID0gQ0ZyYW1lLm5ldygnLi5kLi4nKScpCiAgICBlbHNlaWYgYyA9"
    "PSAnVmVjdG9yMycgdGhlbgogICAgIGxvZyh1cHZhbHMsICdhLicuLmIuLicgPSBWZWN0b3IzLm5l"
    "dygnLi5kLi4nKScpCiAgICBlbHNlaWYgYyA9PSAnVURpbTInIHRoZW4KICAgICBsb2codXB2YWxz"
    "LCAnYS4nLi5iLi4nID0gVURpbTIubmV3KCcuLmQ6Z3N1YigneycsJycpOmdzdWIoJ30nLCcnKS4u"
    "JyknKQogICAgZWxzZWlmIGMgPT0gJ1ZlY3RvcjInIHRoZW4KICAgICBsb2codXB2YWxzLCAnYS4n"
    "Li5iLi4nID0gVmVjdG9yMi5uZXcoJy4uZC4uJyknKQogICAgZWxzZWlmIGMgPT0gJ1VEaW0nIHRo"
    "ZW4KICAgICBsb2codXB2YWxzLCAnYS4nLi5iLi4nID0gVURpbS5uZXcoJy4uZC4uJyknKQogICAg"
    "ZWxzZWlmIGMgPT0gJ0VudW1JdGVtJyB0aGVuCiAgICAgbG9nKHVwdmFscywgJ2EuJy4uYi4uJyA9"
    "ICcuLmQpCiAgICBlbHNlaWYgYyA9PSAnQ29sb3JTZXF1ZW5jZScgdGhlbgogICAgIGxvZyh1cHZh"
    "bHMsICdhLicuLmIuLicgPSBDb2xvclNlcXVlbmNlLm5ldygnLi5kOmdzdWIoJyVzKycsJywnKS4u"
    "JyknKQogICAgZWxzZQogICAgIGxvZyh1cHZhbHMsIGEuLicuJy4uYi4uJyA9ICcuLidbJy4uYy4u"
    "J10gJy4uZCkKICAgIGVuZAogICBlbmQKICBlbmQKICByZXR1cm4gdXB2YWxzCiBlbmQKIHJldHVy"
    "biBvbGRuZXdpbmRleChzZWxmLCBpLCB2KQplbmQpKQoKZ2FtZS5EZXNjZW5kYW50UmVtb3Zpbmc6"
    "Q29ubmVjdChmdW5jdGlvbihhKQogVHJhY2tbYV0gPSBuaWwKZW5kKQoKbG9jYWwgb2xkcHJpbnQg"
    "PSBwcmludApwcmludCA9IG5ld2NjbG9zdXJlKGZ1bmN0aW9uKC4uLikKIGlmIGNoZWNrY2FsbGVy"
    "KCkgYW5kIG5vdCBpc3VpbGliKCkgdGhlbgogIGxvY2FsIGFyZ3MgPSB7Li4ufQogIGxvY2FsIGZv"
    "cm1hdGVkID0ge30KICBmb3IgaSA9IDEsIHNlbGVjdCgnIycsIC4uLikgZG8KICAgbG9jYWwgdiA9"
    "IGFyZ3NbaV0KICAgaWYgdHlwZSh2KSA9PSAndGFibGUnIHRoZW4KICAgIGZvcm1hdGVkW2ldID0g"
    "dGJsZm9ybWF0KHYpCiAgIGVsc2UKICAgIGZvcm1hdGVkW2ldID0gdG9zdHJpbmcodikKICAgZW5k"
    "CiAgZW5kCiAgbG9jYWwgdXB2YWxzID0gb2xkcHJpbnQoLi4uKQogIGxvZyh1cHZhbHMsICdwcmlu"
    "dCgiJy4uIHRhYmxlLmNvbmNhdChmb3JtYXRlZCwnXHQnKSAuLiciKScpCiAgcmV0dXJuIHVwdmFs"
    "cwogZW5kCiByZXR1cm4gb2xkcHJpbnQoLi4uKQplbmQpCgpwcmludCgiW0xvZ2dlcl0gRXhlY3V0"
    "aW5nIHVzZXIgbG9hZHN0cmluZy4uLiIpCnByaW50KCJbTG9nZ2VyXSBBbGwgQVBJIGNhbGxzIHdp"
    "bGwgYmUgbG9nZ2VkIHRvIGxvZ2dlZC50eHQiKQ=="
).decode("utf-8")
 
# ─── Config ───────────────────────────────────────────────────────────────────
BOT_PREFIX = "."
BOT_TOKEN  = "token"
 
LOG_ROLE_ID         = 1487841476900557002
LIST_TARGET_ROLE_ID = 1468930649888002190
LIST_ACCESS_ROLE_ID = 1474441508470915192
 
# ─── Shared access-denied embed ───────────────────────────────────────────────
_PAYMENT_DESC = (
    "**Tokiox Payments Methods**\n\n"
    "\U0001f4b8 **PayPal** \u2014 @claaslolo (only Family and Friends)\n\n"
    "\U0001fa99 **LTC**\n"
    "```\nLKtogDgArVwE54mgXw1MTKA4Wb1qNog4bZ\n```\n"
    "\u20bf **Bitcoin**\n"
    "```\nbc1qyp9dc8t9wnf7tdq055m7da2ke06f220q56g7mv\n```\n"
    "\u039e **Ethereum**\n"
    "```\n0x3625cc98669870D3E5075FB95034e65A3a24Ecef\n```\n"
    "\u25ce **Solana**\n"
    "```\n3hkirw7js7VC81rMbT4e7pR5fPb9kR2XsP1XdDrr8Wuu\n```\n"
    "\U0001f537 **Tron**\n"
    "```\nTWTBcrH1bk3CXA7ChRpMakPXmbM76veobY\n```\n"
    "\U0001f4a0 **XRP**\n"
    "```\nrhBPYRPxYDjQBz3sZNw4WLXVmNB4v7fdTf\n```\n"
    "\U0001f536 **BNB**\n"
    "```\n0x3625cc98669870D3E5075FB95034e65A3a24Ecef\n```"
)
 
 
def _access_denied(command: str, member) -> discord.Embed:
    embed = discord.Embed(
        title="⛔ Access Denied",
        description=f"You don't have the required role to use `{command}`.\n\n{_PAYMENT_DESC}",
        color=0xFF5555,
        timestamp=datetime.utcnow(),
    )
    embed.set_footer(text=f"Requested by {member}", icon_url=member.display_avatar.url)
    return embed
 
 
# ─── Bot setup ────────────────────────────────────────────────────────────────
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(
    command_prefix=BOT_PREFIX,
    intents=intents,
    help_command=None,
    case_insensitive=True,
)
 
 
@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"Logged in as {bot.user}  |  {len(bot.guilds)} servers")
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="Best Deobfuscator",
        )
    )
 
 
# ─── .log ─────────────────────────────────────────────────────────────────────
@bot.command(name="log")
async def log_command(ctx, *, content: str = None):
    # Access Check mit Payment Infos
    if not any(role.id == LOG_ROLE_ID for role in ctx.author.roles):
        embed = _access_denied(".log", ctx.author)
        await ctx.send(embed=embed)
        return

    if not content or not content.strip():
        await ctx.send(
            "Please provide a loadstring after `.log`\n"
            'Example: `.log loadstring(game:HttpGet("https://..."))()`'
        )
        return

    # Logger body ends with two print() lines.
    full_content = _LOGGER_BODY.rstrip("\n") + "\n" + content.strip()

    embed = discord.Embed(
        title="🟢 Successfully Logged",
        description=(
            "**Instructions:**\n"
            "1. Run the attached file in your executor.\n"
            "2. The original script will run with hooks.\n"
            "3. Check your workspace for `logged.txt`."
        ),
        color=0x2ECC71,
        timestamp=datetime.utcnow(),
    )
    embed.set_thumbnail(url="https://i.postimg.cc/QxVJWVsX/Screenshot-2026-04-13-220105.png")
    embed.set_footer(
        text=f"Logged by {ctx.author} • {len(content)} chars added",
        icon_url=ctx.author.display_avatar.url,
    )

    await ctx.send(
        embed=embed,
        file=discord.File(fp=io.StringIO(full_content), filename="logged.txt"),
    )
 
 
# ─── .list ────────────────────────────────────────────────────────────────────
@bot.command(name="list")
async def list_command(ctx):
    if not any(role.id == LIST_ACCESS_ROLE_ID for role in ctx.author.roles):
        embed = discord.Embed(
            title="⛔ Access Denied",
            description="You don't have the required role to use `.list`.",
            color=0xFF5555,
            timestamp=datetime.utcnow(),
        )
        embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)
        return
 
    target_role = ctx.guild.get_role(LIST_TARGET_ROLE_ID)
    if target_role is None:
        await ctx.send("⚠️ Target role not found in this server.")
        return
 
    members = target_role.members
    if not members:
        embed = discord.Embed(
            title=f"📋 Members with role: {target_role.name}",
            description="No members currently have this role.",
            color=0x5865F2,
            timestamp=datetime.utcnow(),
        )
        embed.set_footer(text=f"Requested by {ctx.author}", icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)
        return
 
    lines = []
    for member in sorted(members, key=lambda m: m.joined_at or datetime.utcnow()):
        joined  = member.joined_at.strftime("%Y-%m-%d %H:%M UTC") if member.joined_at else "Unknown"
        created = member.created_at.strftime("%Y-%m-%d") if member.created_at else "Unknown"
        lines.append(
            f"**{member}** (`{member.id}`)\n"
            f"  • Account created: `{created}`\n"
            f"  • Joined server: `{joined}`"
        )
 
    page_size = 10
    pages = [lines[i:i + page_size] for i in range(0, len(lines), page_size)]
    for idx, page in enumerate(pages, start=1):
        embed = discord.Embed(
            title=f"📋 Members with role: {target_role.name}",
            description="\n\n".join(page),
            color=0x5865F2,
            timestamp=datetime.utcnow(),
        )
        embed.set_footer(
            text=f"Page {idx}/{len(pages)}  •  {len(members)} total  •  Requested by {ctx.author}",
            icon_url=ctx.author.display_avatar.url,
        )
        await ctx.send(embed=embed)
 
 
 
# ─── Startup ──────────────────────────────────────────────────────────────────
async def main() -> None:
    await bot.start(BOT_TOKEN)
 
 
asyncio.run(main())